<?php

namespace Gloudemans\Shoppingcart\Exceptions;

use RuntimeException;

class InvalidRowIDException extends RuntimeException {}