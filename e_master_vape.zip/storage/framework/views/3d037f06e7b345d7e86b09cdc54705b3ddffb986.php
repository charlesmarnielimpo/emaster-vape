<!-- JavaScript (jQuery) libraries, plugins and custom scripts-->
<script src="js/vendor.min.js"></script>
<script src="js/scripts.min.js"></script>
<!-- Customizer scripts-->
<script src="customizer/customizer.min.js"></script>