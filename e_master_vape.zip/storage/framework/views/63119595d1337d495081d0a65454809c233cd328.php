<!-- JavaScript (jQuery) libraries, plugins and custom scripts-->
<script src="<?php echo e(asset('/js/vendor.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/scripts.min.js')); ?>"></script>
<script src="<?php echo e(asset('/plugins/validate/jquery.validate.min.js')); ?>"></script>