<!-- Off-Canvas Category Menu-->
<div class="offcanvas-container" id="shop-categories">
  <div class="offcanvas-header">
    <h3 class="offcanvas-title">Shop Categories</h3>
  </div>
  <nav class="offcanvas-menu">
    <ul class="menu">
      <li class="has-children active"><span><a href="index-2.html"><span>Home</span></a></li>
      <li class="has-children"><span><a href="index-2.html"><span>Vaporizers</span></a></li>
      <li class="has-children"><span><a href="shop-grid-ls.html"><span>Liquids</span></a></li>
      <li class="has-children"><span><a href="#">Tanks</a></li>
      <li class="has-children"><span><a href="blog-rs.html"><span>Accessories</span></a></li>
    </ul>
  </nav>
</div>
<!-- Off-Canvas Mobile Menu-->