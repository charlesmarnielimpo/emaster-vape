<!-- JavaScript (jQuery) libraries, plugins and custom scripts-->
<script src="{{ asset('/js/vendor.min.js') }}"></script>
<script src="{{ asset('/js/scripts.min.js') }}"></script>
<script src="{{ asset('/plugins/validate/jquery.validate.min.js') }}"></script>