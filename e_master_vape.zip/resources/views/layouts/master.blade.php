@include('layouts.partials._header')

@yield('stylesheets')

<body>
	@include('layouts.partials._sidebar')
	@include('layouts.partials._topbar')
	
	@yield('content')

	@include('layouts.partials._footer')
	@include('layouts.partials._script')

	@yield('scripts')
</body>
</html>